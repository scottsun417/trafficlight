# -*- coding: utf-8 -*-
import json
import codecs
import cv2
import os
from collections import OrderedDict
from models import *
from my_utils.utils import *
from my_utils.datasets import *
import numpy as np
from my_models.faster_rcnn.resnet import resnet
from my_models.utils.config import cfg, cfg_from_file, cfg_from_list, get_output_dir
from my_models.utils.blob import im_list_to_blob
from my_models.rpn.bbox_transform import bbox_transform_inv
from my_models.rpn.bbox_transform import clip_boxes
# from my_models.nms.nms_cpu import nms_cpu
from torchvision.ops import nms

from model_service.pytorch_model_service import PTServingBaseService

import time
import log
logger = log.getLogger(__name__)


class ObjectDetectionService(PTServingBaseService):
    def __init__(self, model_name, model_path):
        # make sure these files exist
        self.model_name = model_name
        self.model_path = os.path.join(os.path.dirname(__file__), 'faster_rcnn_1_14_1707.pth')
        self.classes_path = os.path.join(os.path.dirname(__file__), 'train_classes.txt')

        self.label_map = parse_classify_rule(os.path.join(os.path.dirname(__file__), 'classify_rule.json'))

        self.input_image_key = 'images'
        self.score_thresh = 0.3
        self.NMS_thresh = 0.45
        self.img_size = 416
        self.classes = self._get_class()
        self.pascal_classes = np.asarray(['__background__',
                     '一次性快餐盒', '书籍纸张', '充电宝', '剩饭剩菜',
                     '包', '垃圾桶', '塑料器皿', '塑料玩具', '塑料衣架',
                     '大骨头', '干电池', '快递纸袋', '插头电线',
                     '旧衣服', '易拉罐', '枕头','果皮果肉',
                     '毛绒玩具', '污损塑料', '污损用纸', '洗护用品',
                     '烟蒂', '牙签', '玻璃器皿', '砧板', '筷子',
                     '纸盒纸箱', '花盆', '茶叶渣', '菜帮菜叶',
                     '蛋壳', '调料瓶', '软膏', '过期药物', '酒瓶',
                     '金属厨具', '金属器皿', '金属食品罐', '锅',
                     '陶瓷器皿', '鞋', '食用油桶', '饮料瓶', '鱼骨'])

        # define and load Faster RCNN model
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = resnet(self.pascal_classes, 101, pretrained=False, class_agnostic=False)
        self.model.create_architecture()
        self.checkpoint = torch.load(self.model_path, map_location=(lambda storage, loc: storage))
        self.model.load_state_dict(self.checkpoint['model'])
        print('load model success')
        # initilize the tensor holder here.
        self.im_data = torch.FloatTensor(1)
        self.im_info = torch.FloatTensor(1)
        self.num_boxes = torch.LongTensor(1)
        self.gt_boxes = torch.FloatTensor(1)
        # make variable
        self.im_data = Variable(self.im_data, volatile=True)
        self.im_info = Variable(self.im_info, volatile=True)
        self.num_boxes = Variable(self.num_boxes, volatile=True)
        self.gt_boxes = Variable(self.gt_boxes, volatile=True)
        self.model.eval()

    def _get_class(self):
        classes_path = os.path.expanduser(self.classes_path)
        with codecs.open(classes_path, 'r', 'utf-8') as f:
            class_names = f.readlines()
        class_names = [c.strip() for c in class_names]
        return class_names

    def _preprocess(self, data):
        preprocessed_data = {}
        for k, v in data.items():
            for file_name, file_content in v.items():
                image = Image.open(file_content)
                image = image.convert('RGB')
                image = np.asarray(image, dtype=np.float32)
                image = cv2.cvtColor(image,cv2.COLOR_RGB2BGR)
                preprocessed_data[k] = image
        return preprocessed_data

    def _inference(self, data):
        """
        model inference function
        Here are a inference example of resnet, if you use another model, please modify this function
        """
        im = data[self.input_image_key]
        blobs, im_scales = _get_image_blob(im)
        im_blob = blobs
        im_info_np = np.array([[im_blob.shape[1], im_blob.shape[2], im_scales[0]]], dtype=np.float32)

        im_data_pt = torch.from_numpy(im_blob)
        im_data_pt = im_data_pt.permute(0, 3, 1, 2)
        im_info_pt = torch.from_numpy(im_info_np)

        # Get detections
        with torch.no_grad():
              self.im_data.resize_(im_data_pt.size()).copy_(im_data_pt)
              self.im_info.resize_(im_info_pt.size()).copy_(im_info_pt)
              self.gt_boxes.resize_(1, 1, 5).zero_()
              self.num_boxes.resize_(1).zero_()
        
        rois, cls_prob, bbox_pred, \
        rpn_loss_cls, rpn_loss_box, \
        RCNN_loss_cls, RCNN_loss_bbox, \
        rois_label = self.model(self.im_data, self.im_info, self.gt_boxes, self.num_boxes)
        scores = cls_prob.data
        boxes = rois.data[:, :, 1:5]
        if cfg.TEST.BBOX_REG:
          # Apply bounding-box regression deltas
          box_deltas = bbox_pred.data
          if cfg.TRAIN.BBOX_NORMALIZE_TARGETS_PRECOMPUTED:
          # Optionally normalize targets by a precomputed mean and stdev
                box_deltas = box_deltas.view(-1, 4) * torch.FloatTensor(cfg.TRAIN.BBOX_NORMALIZE_STDS) \
                               + torch.FloatTensor(cfg.TRAIN.BBOX_NORMALIZE_MEANS)
                box_deltas = box_deltas.view(1, -1, 4 * len(self.pascal_classes))

          pred_boxes = bbox_transform_inv(boxes, box_deltas, 1)
          pred_boxes = clip_boxes(pred_boxes, self.im_info.data, 1)
        else:
          # Simply repeat the boxes, once for each class
          pred_boxes = np.tile(boxes, (1, scores.shape[1]))

        pred_boxes /= im_scales[0]

        scores = scores.squeeze()
        pred_boxes = pred_boxes.squeeze()

        out_boxes = []
        out_scores = []
        out_classes = []
        for j in range(1, len(self.pascal_classes)):
          inds = torch.nonzero(scores[:,j]>self.score_thresh).view(-1)
          # if there is det
          if inds.numel() > 0:
            cls_scores = scores[:,j][inds]
            _, order = torch.sort(cls_scores, 0, True)
            cls_boxes = pred_boxes[inds][:, j * 4:(j + 1) * 4]
            
            cls_dets = torch.cat((cls_boxes, cls_scores.unsqueeze(1)), 1)
            # cls_dets = torch.cat((cls_boxes, cls_scores), 1)
            cls_dets = cls_dets[order]
            # keep = nms(cls_dets, cfg.TEST.NMS, force_cpu=not cfg.USE_GPU_NMS)
            keep = nms(boxes=cls_boxes[order, :],
                           scores=cls_scores[order],
                           iou_threshold=self.NMS_thresh)
            cls_dets = cls_dets[keep.view(-1).long()]
            cls_dets = cls_dets.numpy().tolist()
            for x in cls_dets:
                out_boxes.append(x[:4])
                out_scores.append(x[4])
#                 out_boxes.append(x[:4] for x in cls_dets)
#                 out_scores.extend([x[4] for x in cls_dets])
                out_classes.extend([self.pascal_classes[j]])
            
        result = OrderedDict()
        if out_boxes is not None:
            detection_class_names = []
            for class_name in out_classes:
                class_name = self.label_map[class_name] + '/' + class_name
                detection_class_names.append(class_name)
            out_boxes_list = []
            for box in out_boxes:
                out_boxes_list.append([round(float(v), 1) for v in box])
            result['detection_classes'] = detection_class_names
            result['detection_scores'] = [round(float(v), 4) for v in out_scores]
            result['detection_boxes'] = out_boxes_list
        else:
            result['detection_classes'] = []
            result['detection_scores'] = []
            result['detection_boxes'] = []

        return result

    def _postprocess(self, data):
        return data

    def inference(self, data):
        '''
        Wrapper function to run preprocess, inference and postprocess functions.

        Parameters
        ----------
        data : map of object
            Raw input from request.

        Returns
        -------
        list of outputs to be sent back to client.
            data to be sent back
        '''
        pre_start_time = time.time()
        data = self._preprocess(data)
        infer_start_time = time.time()
        # Update preprocess latency metric
        pre_time_in_ms = (infer_start_time - pre_start_time) * 1000
        print('preprocess time: ' + str(pre_time_in_ms) + 'ms')

        data = self._inference(data)
        infer_end_time = time.time()
        infer_in_ms = (infer_end_time - infer_start_time) * 1000

        print('infer time: ' + str(infer_in_ms) + 'ms')
        data = self._postprocess(data)

        # Update inference latency metric
        post_time_in_ms = (time.time() - infer_end_time) * 1000
        print('postprocess time: ' + str(post_time_in_ms) + 'ms')

        # Update overall latency metric

        print('latency: ' + str(pre_time_in_ms + infer_in_ms + post_time_in_ms) + 'ms')
        data['latency_time'] = str(round(pre_time_in_ms + infer_in_ms + post_time_in_ms, 1)) + ' ms'
        return data

def _get_image_blob(im):
  """Converts an image into a network input.
  Arguments:
    im (ndarray): a color image in BGR order
  Returns:
    blob (ndarray): a data blob holding an image pyramid
    im_scale_factors (list): list of image scales (relative to im) used
      in the image pyramid
  """
  im_orig = im.astype(np.float32, copy=True)
  im_orig -= cfg.PIXEL_MEANS

  im_shape = im_orig.shape
  im_size_min = np.min(im_shape[0:2])
  im_size_max = np.max(im_shape[0:2])

  processed_ims = []
  im_scale_factors = []

  for target_size in cfg.TEST.SCALES:
    im_scale = float(target_size) / float(im_size_min)
    # Prevent the biggest axis from being more than MAX_SIZE
    if np.round(im_scale * im_size_max) > cfg.TEST.MAX_SIZE:
      im_scale = float(cfg.TEST.MAX_SIZE) / float(im_size_max)
    im = cv2.resize(im_orig, None, None, fx=im_scale, fy=im_scale,
            interpolation=cv2.INTER_LINEAR)
    im_scale_factors.append(im_scale)
    processed_ims.append(im)

  # Create a blob to hold the input images
  blob = im_list_to_blob(processed_ims)

  return blob, np.array(im_scale_factors)

def parse_classify_rule(json_path=''):
    with codecs.open(json_path, 'r', 'utf-8') as f:
        rule = json.load(f)
    label_map = {}
    for super_label, labels in rule.items():
        for label in labels:
            label_map[label] = super_label
    return label_map
